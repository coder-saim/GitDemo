#include <bits/stdc++.h>
using namespace std;

int dp[100][100];

// Time Complexity: O(2^n)
int knapSack_recursion(int W, int wt[], int val[], int n){
    // Base Case
    if (n == 0 || W == 0)
        return 0;

    // If weight of the nth item is more than Knapsack capacity W, then this item cannot be included in the optimal solution
    if (wt[n - 1] > W)
        return knapSack_recursion(W, wt, val, n - 1);

    // Return the maximum of two cases:
    // (1) nth item included
    // (2) not included
    else
        return max(val[n - 1] + knapSack_recursion(W - wt[n - 1],  wt, val, n - 1), knapSack_recursion(W, wt, val, n - 1));
}

// Time Complexity: O(n*W).
int knapSack_recursion_dp(int W, int wt[], int val[], int n){

    if (n == 0 || W == 0)
        return 0;

    if(dp[n][W]!=-1) return dp[n][W];

    int result;
    
    if (wt[n - 1] > W)
        result = knapSack_recursion_dp(W, wt, val, n - 1);

    else
        result = max(val[n-1] + knapSack_recursion_dp(W - wt[n - 1], wt, val, n - 1), knapSack_recursion_dp(W, wt, val, n - 1));

    return dp[n][W] = result;
}

// Time Complexity: O(n*W).
int knapSack_bottomUp(int W, int wt[], int val[], int n){
    int i, w;
    vector<vector<int>> K(n + 1, vector<int>(W + 1));

    // Build table K[][] in bottom up manner
    for (i = 0; i <= n; i++){
        for (w = 0; w <= W; w++){
            if (i == 0 || w == 0) K[i][w] = 0;
            else if (wt[i - 1] <= w)
                K[i][w] = max(val[i - 1] + K[i - 1][w - wt[i - 1]], K[i - 1][w]);
            else
                K[i][w] = K[i - 1][w];
        }
    }
    return K[n][W];
}

int main(){
    int val[] = {60, 100, 120};
    int wt[] = {10, 20, 30};
    int W = 50;
    int n = sizeof(val) / sizeof(val[0]);
    memset(dp,-1,sizeof(dp));
    cout << knapSack_recursion(W, wt, val, n)<<endl;
    cout << knapSack_recursion_dp(W, wt, val, n)<<endl;
    cout << knapSack_bottomUp(W, wt, val, n)<<endl;
    return 0;
}

