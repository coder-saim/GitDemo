#include <bits/stdc++.h>
#include <chrono>
using namespace std::chrono;
using namespace std;


int lis_recursion(int idx, int prev_idx, int n, int a[])
{
    if (idx == n)
        return 0;
    int notTake = 0 + lis_recursion(idx + 1, prev_idx, n, a);
    int take = INT_MIN;
    if (prev_idx == -1 || a[idx] > a[prev_idx])
    {
        take = 1 + lis_recursion(idx + 1, idx, n, a);
    }
    return max(take, notTake);
}


int lis_recursion_dp(int idx, int prev_idx, int n, int a[],vector<vector<int>> &dp){
    if (idx == n)
    {
        return 0;
    }
    if (dp[idx][prev_idx + 1] != -1)
    {
        return dp[idx][prev_idx + 1];
    }
    int notTake = 0 + lis_recursion_dp(idx + 1, prev_idx, n, a, dp);
    int take = INT_MIN;
    if (prev_idx == -1 || a[idx] > a[prev_idx])
    {
        take = 1 + lis_recursion_dp(idx + 1, idx, n, a, dp);
    }
    return dp[idx][prev_idx + 1] = max(take, notTake);
}


int lis_bottomUp(int arr[], int n)
{
    int lis[n];
    lis[0] = 1;
    for (int i = 1; i < n; i++) {
        lis[i] = 1;
        for (int j = 0; j < i; j++)
            if (arr[i] > arr[j] && lis[i] < lis[j] + 1)
                lis[i] = lis[j] + 1;
    }
 
    return *max_element(lis, lis + n);
}


int main(){
    freopen("inp.txt", "r", stdin);
    freopen("output.txt", "a", stdout);
    auto start = high_resolution_clock::now();
    long long int ans1=0,ans2=0,ans3=0;
    int n, m;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        cin >> m;
        int a[1000000];
        for (int j = 0; j < m; j++)
        {
            cin >> a[j];
        }
        ans1+=lis_bottomUp(a,m);;
    }
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    cout <<"Bottom Up/ : "<<ans1<<" "<< duration.count() << endl;
}