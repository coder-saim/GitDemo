#include <bits/stdc++.h>
using namespace std;

// Time Complexity: O(2^n)
int cutRod_resursion(int price[], int index, int n){
    // base case
    if (index == 0)
        return n * price[0];
    
    // At any index we have 2 options either
    // cut the rod of this length or not cut
    // it
    int notCut = cutRod_resursion(price, index - 1, n);
    int cut = INT_MIN;
    int rod_length = index + 1;

    if (rod_length <= n)
        cut = price[index] + cutRod_resursion(price, index, n - rod_length);

    return max(notCut, cut);
}

// Time Complexity: O(n^2)
int cutRod_resursion_dp(int price[], int index, int n, vector<vector<int>> &dp){
    
    if (index == 0)
        return n * price[0];
    
    if (dp[index][n] != -1)
        return dp[index][n];
    
    int notCut = cutRod_resursion_dp(price, index - 1, n, dp);
    int cut = INT_MIN;
    int rod_length = index + 1;

    if (rod_length <= n)
        cut = price[index] + cutRod_resursion_dp(price, index, n - rod_length, dp);

    return dp[index][n] = max(notCut, cut);
}

// Time Complexity: O(n^2)
int cutRod_bottomUp(int price[], int n){
    int val[n + 1];
    val[0] = 0;
    int i, j;

    for (i = 1; i <= n; i++){
        int max_val = INT_MIN;
        for (j = 0; j < i; j++)
            max_val = max(max_val, price[j] + val[i - j - 1]);
        val[i] = max_val;
    }

    return val[n];
}

int main(){
    int arr[] = {1, 5, 8, 9, 10, 17, 17, 20};
    int size = sizeof(arr) / sizeof(arr[0]);
    vector<vector<int>> dp(size,vector<int>(size + 1, -1));
    cout << "Maximum Obtainable Value is " << cutRod_resursion(arr, size - 1, size) << endl;
    cout << "Maximum Obtainable Value is " << cutRod_resursion(arr, size - 1, size) << endl;
    cout << "Maximum Obtainable Value is " << cutRod_bottomUp(arr,size) << endl;
    return 0;
}
