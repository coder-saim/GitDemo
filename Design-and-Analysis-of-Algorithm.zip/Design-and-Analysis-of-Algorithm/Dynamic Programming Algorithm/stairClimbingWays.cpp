// Count ways to reach the n’th stair
// There are n stairs, a person standing at the bottom wants to reach the top.
//The person can climb either 1 stair or 2 stairs at a time. Count the number of ways, the person can reach the top.

#include <bits/stdc++.h>
using namespace std;


// Returns number of ways to reach s'th stair
//Time Complexity : O(2^n) 
int countWays_recursion(int n){
    if (n <= 1) return 1;
    return countWays_recursion(n - 1) + countWays_recursion(n - 2);
}

//Time Complexity : O(n) 
int countWays_recursion_dp(int n, vector<int> &dp){

    if (n <= 1) return dp[n] = 1;

    if (dp[n] != -1) return dp[n];
    
    dp[n] = countWays_recursion_dp(n - 1, dp) + countWays_recursion_dp(n - 2, dp);
    return dp[n];
}

// Time Complexity : O(n*m)
int countWays_bottomUp(int n, int m){
    int res[n];
    res[0] = 1;
    res[1] = 1;

    for (int i = 2; i < n; i++){
        res[i] = 0;
        for (int j = 1; j <= m && j <= i; j++)
            res[i] += res[i - j];
    }
    return res[n - 1];
}

int main(){
    int s = 4;
    vector<int> dp(s+1,-1);
    cout << "Number of ways = " << countWays_recursion(s)<<endl;
    cout << "Number of ways = " << countWays_recursion_dp(s, dp)<<endl;
    cout << "Number of ways = " << countWays_bottomUp(s+1, 5) << endl;

    return 0;
}

// This code is contributed by shubhamsingh10
