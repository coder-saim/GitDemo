#include<bits/stdc++.h>
using namespace std;
using namespace std::chrono; 


struct Matrix{
    int n,m;
    vector<vector<int>>mat;
    Matrix(int _n, int _m){
        n = _n;
        m = _m;
        mat.resize(n,vector<int>(m,0));
    }
    Matrix operator *(Matrix &b){
        assert(m==b.n);
        Matrix tmp(n,b.m);
        for(int i=0;i<n;i++){
            for(int j=0;j<b.m;j++){
                for(int k = 0;k<m;k++){
                    tmp.mat[i][j]+=(mat[i][k]*b.mat[k][j]);
                }
            }
        }
        return tmp;
    }
    Matrix operator =(Matrix &b){
        Matrix tmp(b.n,b.m);
        for(int i=0;i<b.n;i++) {
            for(int j=0;j<b.m;j++){
                tmp.mat[i][j]=b.mat[i][j];
            }
        }
        return tmp;
    }
    void display(){
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                cout<<mat[i][j]<<" ";
            }
            cout<<endl;
        }
    }
};

vector<Matrix>arr;
int n;

int dp[1001][1001];

int Matrix_chain_multiplication(int i, int j){
    if(i==j){
        return 0;
    }
    if(dp[i][j]!=-1){
        return dp[i][j];
    }
    dp[i][j] = INT_MAX;

    for (int k = i; k < j; k++){
        dp[i][j] = min(dp[i][j], Matrix_chain_multiplication(i,k) + Matrix_chain_multiplication(k + 1,j)+ arr[i].n * arr[k].m * arr[j].m);
    }
    return dp[i][j];
}

Matrix print_sequence(int i , int j){
    
    if(i==j){
        cout<<i+1;
        return arr[i];
    }
    int brk = -1;
    int mx = INT_MAX;
    for(int k=i;k<j;k++){
        if(mx>dp[i][k]+dp[k+1][j]+arr[i].n * arr[k].m * arr[j].m){
            mx = dp[i][k]+dp[k+1][j]+arr[i].n * arr[k].m * arr[j].m;
            brk = k;
        }
    }
    cout<<"(";
    Matrix x = print_sequence(i,brk);
    cout<<")";
    cout<<"(";
    Matrix y = print_sequence(brk+1,j);
    cout<<")";
    return x*y;
}

int main(){
    ios_base::sync_with_stdio(false),cin.tie(NULL),cout.tie(NULL);
    freopen("input.txt","r",stdin); freopen("output.txt","w",stdout);
    
    cin>>n;
    arr;
    for(int k=0;k<n;k++){
        int a,b;
        cin>>a>>b;
        Matrix tmp(a,b);
        for(int i=0;i<tmp.n;i++){
            for(int j=0;j<tmp.m;j++){
                cin>>tmp.mat[i][j];
            }
        }
        arr.push_back(tmp);
        cout<<"Matrix: "<<k+1<<endl;
        tmp.display();
        cout<<endl;
    }
    memset(dp,-1,sizeof(dp));

    int ans = Matrix_chain_multiplication(0,arr.size()-1);
    cout<<"Max operation will be: "<<ans<<endl;

    Matrix mul = print_sequence(0,arr.size()-1);

    cout<<"\n\nThe resultant matrix is "<<endl;

    mul.display();
    

    return 0;
}