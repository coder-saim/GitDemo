Matrix operator =(Matrix &b){
    //     Matrix tmp(b.n,b.m);
    //     for(int i=0;i<b.n;i++) {
    //         for(int j=0;j<b.m;j++){
    //             tmp.mat[i][j]=b.mat[i][j];
    //         }
    //     }
    //     return tmp;
    // }