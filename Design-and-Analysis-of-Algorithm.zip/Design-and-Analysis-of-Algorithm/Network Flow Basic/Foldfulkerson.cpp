#include <bits/stdc++.h>
#include<chrono>
using namespace std;
using namespace std::chrono;
#define INF 1000
int n;
int e;
int src;
int snk;
vector<vector<int>> capacity,capacity1;
vector<vector<int>> adj,adj1;
bool reached = false;

int bfs(int s, int t, vector<int> &parent)
{
    fill(parent.begin(), parent.end(), -1);
    parent[s] = -2;
    queue<pair<int, int>> q;
    q.push({s, INF});

    while (!q.empty())
    {
        int cur = q.front().first;
        int flow = q.front().second;
        q.pop();

        for (int next : adj1[cur])
        {
            if (parent[next] == -1 && capacity1[cur][next])
            {
                parent[next] = cur;
                int new_flow = min(flow, capacity1[cur][next]);
                if (next == t)
                    return new_flow;
                q.push({next, new_flow});
            }
        }
    }

    return 0;
}

int maxflow1(int s, int t)
{
    int flow = 0;
    vector<int> parent(n+5);
    int new_flow;

    while (new_flow = bfs(s, t, parent))
    {
        flow += new_flow;
        int cur = t;
        while (cur != s)
        {
            int prev = parent[cur];
            capacity1[prev][cur] -= new_flow;
            capacity1[cur][prev] += new_flow;
            cur = prev;
        }
    }

    return flow;
}


int dfsh(int s, vector<int> &parent, vector<int> &vis)
{
    vis[s] = 0;
    int flow = INF;
    for (auto i : adj[s])
    {
        if(reached) return flow;
        if (vis[i] == -1 && capacity[s][i] > 0)
        {
            cout << s << "--" << i << endl;
            parent[i] = s;
            flow = capacity[s][i];
            if (i == snk)
            {
                reached = true;
                return flow;
            }
            flow = min(flow, dfsh(i, parent, vis));
        }
    }
    return flow;
}

int dfs(int s, int t, vector<int> &parent)
{
    fill(parent.begin(), parent.end(), -1);
    parent[s] = -2;
    reached = false;
    int cur_flow = INF;
    vector<int> vis(n + 5, -1);
    cur_flow = min(cur_flow, dfsh(src, parent, vis));
    if (reached)
        return cur_flow;
    return 0;
}

int maxflow(int s, int t)
{
    int flow = 0;
    vector<int> parent(n + 5);
    int new_flow = 1;

    while (new_flow = dfs(s, t, parent))
    {
        cout<<new_flow<<endl;
        flow += new_flow;
        int cur = t;
        while (cur != s)
        {
            int prev = parent[cur];
            capacity[prev][cur] -= new_flow;
            capacity[cur][prev] += new_flow;
            cur = prev;
        }
        // for (int i = 0; i <= n; i++)
        // {
        //     for (int j = 0; j <= n; j++)
        //         cout << capacity[i][j] << " ";
        //     cout << endl;
        // }
    }

    return flow;
}

int main(){
    freopen("input.txt","r",stdin);
    cin >> n>>e;
    capacity.assign(n + 1, vector<int>(n + 1, 0));
    adj.assign(n + 1, vector<int>());
    capacity1.assign(n + 1, vector<int>(n + 1, 0));
    adj1.assign(n + 1, vector<int>());
    for (int i = 0; i < e; i++)
    {
        int from, to, flw;
        cin >> from >> to >> flw;
        capacity[from][to] = flw;
        adj[from].push_back(to);
        adj[to].push_back(from);

        capacity1[from][to] = flw;
        adj1[from].push_back(to);
        adj1[to].push_back(from);
    }
    src = 0;
    snk = 5;

    cout <<"Foldfulkerson\n";
    auto st = chrono:: high_resolution_clock:: now();
    cout<< maxflow(src, snk) << "\n";
    auto ed = chrono:: high_resolution_clock:: now();
    auto duration = chrono::duration_cast<chrono::microseconds>(ed-st);
    cout<<"Time for dfs = "<<duration.count()<<endl;

    st = chrono:: high_resolution_clock:: now();
    cout <<"EdmonsKarp " <<maxflow1(src, snk) << "\n";
    ed = chrono:: high_resolution_clock:: now();
    duration = chrono::duration_cast<chrono::microseconds>(ed-st);
    cout<<"Time for bfs = "<<duration.count()<<endl;    
}